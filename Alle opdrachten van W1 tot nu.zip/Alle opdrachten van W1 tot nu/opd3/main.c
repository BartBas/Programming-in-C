#include <stdio.h>
#include <string.h>

int main()
{

	int number, x;
	printf("Kies het aantal sterren\n");
	scanf("%d", &number);
	x = 0;
	char aantal[256] = "";
	char ster[] = "*";	
	
	void removeEndingColon(char *charArrayWithColon) {
    // remove ':' from variableName
    size_t indexOfNullTerminator = strlen(charArrayWithColon);
    charArrayWithColon[indexOfNullTerminator - 1] = '\0'; // replace ':' with '\0'
}
	if(number<81&&number>0){
		while(x<number){
			strcat(aantal, ster);
			printf(aantal);
			printf("\n");
			x = (x+1);
			
			}
		while(0<x){
			removeEndingColon(aantal);
			printf(aantal);
			printf("\n");
			x = x-1;
			}
			
		} else {
			printf("Aantal sterren valt buiten de waardes. (probeer 0 < x <81)");
			}

	return(0);
}

#include <stdio.h>
#include <iostream>
#include <cstring>
using namespace std;
 
void Reverse(char *);
 
int main()
{
 char s[100];
 cout<<"\nEnter the string=";
 cin.getline(s,100);
 Reverse(s);
 
 getch();
}
 
void Reverse(char *s)
{
 for(int i=0, j=strlen(s)-1;i<j;i++,j--)
 {
 char temp=s[j];
 s[j]=s[i];
 s[i]=temp;
 }
 cout<<"\nReverse="<<s<<"\n";
 return(0);
}
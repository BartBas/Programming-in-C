#include "queue.h"

int main() {

    Queue queue;
    init_queue(&queue);

    enqueue(&queue, 1);
    enqueue(&queue, 2);
    enqueue(&queue, 3);
    enqueue(&queue, 4);
    enqueue(&queue, 5);
    show(queue);
    dequeue(&queue);
    dequeue(&queue);
    dequeue(&queue);
    enqueue(&queue, 1);
    show(queue);
    return 1;
}

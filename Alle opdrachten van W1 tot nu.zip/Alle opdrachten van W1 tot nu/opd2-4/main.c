#include <stdio.h>

int main()
{
	int tekst1;
	char tekst2[20];
	double tekst3 ;
	double tekst4 ;
	
	printf("nummer: \n");
	scanf("%i", tekst1);
	
	printf("naam: \n");
	scanf("%s", tekst2);
	
	printf("gewicht: \n");
	scanf("%f", tekst3);
	
	printf("lengte: \n");
	scanf("%f", tekst4);
	
	printf("%s heeft nummer %i, weegt %f en is %f centimeter", tekst2, tekst1, tekst3, tekst4);
	
	return(0);
}
